<?php
// $servername = "localhost";
// $username = "usuario1";
// $password = "wopper22";
// $database = "palabras_base";

$servername = "163.10.35.34";

$username = "root";
$password = "secyt";

//$username = "palabra3_berugocarambula";
//$password = "mN^sJwt*EqY$";

$database = "palabra3_base";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
mysqli_set_charset( $conn, 'utf8');
/*print_r($conn);
if (!$conn) {
    die('Error de conexión: ' . mysqli_connect_error());
}*/



function seo_url($cadena){
    $cadena= utf8_decode($cadena);
    $cadena = str_replace(' ', '-', $cadena);
    $cadena = str_replace('?', '', $cadena);
    $cadena = str_replace('+', '', $cadena);
    $cadena = str_replace(':', '', $cadena);
    $cadena = str_replace('??', '', $cadena);
    $cadena = str_replace('`', '', $cadena);
    $cadena = str_replace('!', '', $cadena);
    $cadena = str_replace('¿', '', $cadena);
    $cadena = str_replace('"', '', $cadena);
    $originales = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿ??';
    $modificadas = 'aaaaaaaceeeeiiiidnoooooouuuuybsaaaaaaaceeeeiiiidnoooooouuuyybyRr';
    $cadena = strtr($cadena, utf8_decode($originales), $modificadas);

    return $cadena;

}



?>
